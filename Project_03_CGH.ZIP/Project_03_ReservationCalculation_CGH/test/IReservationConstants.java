


import java.time.LocalDate;

public interface IReservationConstants {
    final double NIGHTLY_RATE = 95.00;
}
